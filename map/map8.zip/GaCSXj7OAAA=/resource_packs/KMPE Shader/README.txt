𝗥𝗘𝗔𝗗𝗠𝗘

This pack is originally made by 𝗭𝗵𝗲𝗸𝗮 𝗦𝗺𝗶𝗿𝗻𝗼𝘃, the pack had been remake by me, 𝗗𝗮𝘃𝗶𝗱𝗕𝗹𝗼𝗰𝗰.

𝗧𝘄𝗶𝘁𝘁𝗲𝗿 - @DavidBlocc
𝗧𝘄𝗶𝘁𝘁𝗲𝗿 - @LSumfuk

The one who help me remaking the shader is,
𝗘𝗹𝗱𝗲𝘀𝘁𝗼𝗻 ( The Developer of 𝗘𝗦𝗧𝗡 𝗦𝗵𝗮𝗱𝗲𝗿𝘀 )

𝗧𝘄𝗶𝘁𝘁𝗲𝗿 - @eldeston

𝗙𝗲𝗮𝘁𝘂𝗿𝗲𝘀 of the remake :

I - Parallax Torch ( Flickering Torch )
II - Custom Rendered Water
III - Fake Player Shadow
IV - Fake Shadows

𝗕𝘂𝗴𝘀 that cannot possibly be fixed : ( Some are possible though )

I - If a Water Bucket is spilled, the position of the Sun Reflection will be incorrect.

II - The flowing Water Texture will be incorrect if a Water Bucket is spilled. This is because there are codes that involved in resizing the water texture.

III - The Custom Rendered Water will be pixelated if the feature Texel Anti-Aliasing is disabled. Luckily, this problem can be fixed in the 'options.txt' file.

IV - Bad news, if the feature Texel Anti-Aliasing is enabled, the blocks in Minecraft will have outlines. This is because the resolution of the Water Texture is mixed with low resolution textures.

V - More bad news, we can eliminate the outlines of the blocks, but the Custom Rendered Water will be devastated.

𝗦𝗼𝗹𝘂𝘁𝗶𝗼𝗻𝘀 for the outlines :

I - The outlines can be eliminated in the 'terrain_texture.json' file.

II - The outlines can be eliminated if the feature Texel Anti-Aliasing is disabled. But as I said before, the Water will be devastated.

𝗡𝗼𝘁𝗲 :

The remake will not work for some devices, mostly for people that uses iOS Devices. Some will work, some will not, the same for Android Devices.

𝗘𝗡𝗗 𝗢𝗙 𝗧𝗘𝗫𝗧